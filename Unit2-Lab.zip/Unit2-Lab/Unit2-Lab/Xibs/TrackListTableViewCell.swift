import UIKit
import Nuke

class TrackListTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var trackImage: UIImageView!
    @IBOutlet weak var artistName: UILabel!
    @IBOutlet weak var trackName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        trackImage.layer.cornerRadius = 8
    }
    
    var currentTrack: TrackObj? {
        didSet {
            if let currentTrack = currentTrack {
                configureCell(track: currentTrack)
            }
        }
    }
    
    private func configureCell(track: TrackObj) {
        artistName.text = track.artistName
        trackName.text = track.trackName
        Nuke.loadImage(with: URL(string: track.artworkUrl100)!, into: trackImage, completion: nil)
    }
}
