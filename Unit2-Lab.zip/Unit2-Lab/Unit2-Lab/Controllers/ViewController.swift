import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var trackTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        trackTableView.register(TrackListTableViewCell.self)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return TrackObj.mockTracks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let trackCell = trackTableView.dequeueReusableCell(withIdentifier: TrackListTableViewCell.identifier, for: indexPath) as? TrackListTableViewCell {
            trackCell.currentTrack = TrackObj.mockTracks[indexPath.row]
            return trackCell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "detailVCSegue", sender: self)
    }
}

extension ViewController {
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let detailVCSegue = segue.destination as? DetailViewController {
            if let indexPath = trackTableView.indexPathForSelectedRow {
                detailVCSegue.selectedTrack = TrackObj.mockTracks[indexPath.row]
            }
        }
    }
}
