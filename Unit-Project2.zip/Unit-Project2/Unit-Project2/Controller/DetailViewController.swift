import UIKit
import Nuke

class DetailViewController: UIViewController {
    
    var selectedTrack: TrackObj?
    
    @IBOutlet weak var trackImage: UIImageView!
    @IBOutlet weak var artistNamee: UILabel!
    @IBOutlet weak var collection: UILabel!
    @IBOutlet weak var trackName: UILabel!
    @IBOutlet weak var genre: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var date: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let selectedTrack = selectedTrack {
            configureTrackDetails(track: selectedTrack)
        }
    }
    
    private func configureTrackDetails(track: TrackObj) {
        artistNamee.text = track.artistName
        trackName.text = track.trackName
        Nuke.loadImage(with: URL(string: track.artworkUrl100)!, into: trackImage, completion: nil)
        genre.text = track.primaryGenreName
        collection.text = track.collectionName
        date.text = track.releaseDate.FormatteDate()
        time.text = track.trackTimeMillis.convertIntToMmSs()
    }
}
