import Foundation

struct KTrack {
    
    struct ArtistName {
        
        static let artist1 = "Henri Matisse"
        static let artist2 = "Rembrandti Michelangelo"
        static let artist3 = "Claude"
        static let artist4 = "Salvador Dalí"
        static let artist5 = "Rene Magritte"
        
    }
    
    struct TrackName {
        
        static let track1 = "Salvador Dalí"
        static let track2 = "The 59th Street Bridge Song (Feelin' Groovy)"
        static let track3 = "Life without friends"
        static let track4 = "Act Naturally"
        static let track5 = "The Cowboy"
        
    }
    
    struct CollectionName {
        
        static let collection = "The Music Album"
    }
    
    struct PrimaryGenre {
        
        static let genre = "Rock Singer "
    }
    
    struct TrackTime {
        
        static let timeInMilliSeconds = 20978
    }
    
    struct ArtworkUrl {
        
        static let url1 = "https://cdn.vox-cdn.com/thumbor/7luDvliFcVsKQ2LRjruUl5qAMsg=/0x0:3200x1800/1200x675/filters:focal(1344x644:1856x1156)/cdn.vox-cdn.com/uploads/chorus_image/image/64747907/staff_disney_songs_ringer.0.jpg"
        static let url2 = "https://cdn.britannica.com/03/151903-131-E310E9EC/Microphone-background-sound-waves-energy-Music.jpg"
        static let url3 = "https://images.unsplash.com/photo-1619983081563-430f63602796?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80"
        static let url4 = "https://hips.hearstapps.com/hmg-prod/images/index-thanksgiving-1668008610.jpg"
        static let url5 = "https://plus.unsplash.com/premium_photo-1681396936891-ed738c53cb21?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2788&q=80"
        
    }
    
}
