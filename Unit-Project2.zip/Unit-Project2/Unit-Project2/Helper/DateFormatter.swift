import Foundation

extension Date {
    
    func FormatteDate() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm E, d MMM y"
        return formatter.string(from: self)
    }
}

extension Int {
    
    func convertIntToMmSs() -> String {
        let formatter = DateComponentsFormatter()
        formatter.allowedUnits = [.minute, .second]
        formatter.unitsStyle = .short
        return formatter.string(from: TimeInterval(self)) ?? ""
    }
}
