import Foundation

struct Track: Codable {
    
    let trackCount: Int
    let trackList: [TrackObj]
    
}

// MARK: - Result
struct TrackObj: Codable {
    
    let artistName: String
    let trackName: String
    let artworkUrl100: String
    let collectionName: String?
    let releaseDate: Date
    let primaryGenreName: String
    let trackTimeMillis: Int
    
    enum CodingKeys: String, CodingKey {
        
        case artistName, trackName, artworkUrl100
        case releaseDate, trackTimeMillis, primaryGenreName, collectionName
    }
}

extension TrackObj {
    
    static var mockTracks: [TrackObj] = [
        
        TrackObj(artistName: KTrack.ArtistName.artist1, trackName: KTrack.TrackName.track1, artworkUrl100: KTrack.ArtworkUrl.url1, collectionName: KTrack.CollectionName.collection, releaseDate: Date(), primaryGenreName: KTrack.PrimaryGenre.genre, trackTimeMillis: KTrack.TrackTime.timeInMilliSeconds),
        TrackObj(artistName: KTrack.ArtistName.artist2, trackName: KTrack.TrackName.track2, artworkUrl100: KTrack.ArtworkUrl.url2, collectionName: KTrack.CollectionName.collection, releaseDate: Date(), primaryGenreName: KTrack.PrimaryGenre.genre, trackTimeMillis: KTrack.TrackTime.timeInMilliSeconds),
        TrackObj(artistName: KTrack.ArtistName.artist3, trackName: KTrack.TrackName.track3, artworkUrl100: KTrack.ArtworkUrl.url3, collectionName: KTrack.CollectionName.collection, releaseDate: Date(), primaryGenreName: KTrack.PrimaryGenre.genre, trackTimeMillis: KTrack.TrackTime.timeInMilliSeconds),
        TrackObj(artistName: KTrack.ArtistName.artist4, trackName: KTrack.TrackName.track4, artworkUrl100: KTrack.ArtworkUrl.url4, collectionName: KTrack.CollectionName.collection, releaseDate: Date(), primaryGenreName: KTrack.PrimaryGenre.genre, trackTimeMillis: KTrack.TrackTime.timeInMilliSeconds),
        TrackObj(artistName: KTrack.ArtistName.artist5, trackName: KTrack.TrackName.track5, artworkUrl100: KTrack.ArtworkUrl.url5, collectionName: KTrack.CollectionName.collection, releaseDate: Date(), primaryGenreName: KTrack.PrimaryGenre.genre, trackTimeMillis: KTrack.TrackTime.timeInMilliSeconds)
        
    ]
    
}
